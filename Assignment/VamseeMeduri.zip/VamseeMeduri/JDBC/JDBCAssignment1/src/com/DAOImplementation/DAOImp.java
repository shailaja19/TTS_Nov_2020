package com.DAOImplementation;

import java.util.List;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.DAO.*;
import com.Model.*;

public class DAOImp implements ProdDAO{
	int row = 0;
	DBConnector db = new DBConnector();
	Product product = new Product();
	@Override
	public int add(Object ob) {
		product = (Product)ob;
		try {
			PreparedStatement ps = db.getConnection().prepareStatement
								("insert into Products values(?,?,?)");
			ps.setInt(1, product.getProductID());
			ps.setString(2, product.getProductName());
			ps.setDouble(3, product.getProductPrice());
			row = ps.executeUpdate();
			db.closeConnection();
		}catch(SQLException e) {e.printStackTrace();}
		return row;
	}
	
	@Override
	public int delete(Object ob) {
		product = (Product)ob;
		int temp = product.getProductID();
		try {
			PreparedStatement ps = db.getConnection().prepareStatement("delete from Products where productID = ?");
			ps.setInt(1, temp);
			row = ps.executeUpdate();
			db.closeConnection();
		}catch(SQLException e) {e.printStackTrace();}
		return row;
	}
	
	@Override
	public int update(Object ob) {
		product = (Product)ob;
		try {
			PreparedStatement ps = db.getConnection().prepareStatement("update Products set productName = ?, productPrice = ? where productID = ?");
			ps.setString(1, product.getProductName());
			ps.setDouble(2, product.getProductPrice());
			ps.setDouble(3, product.getProductID());
			row = ps.executeUpdate();
			db.closeConnection();
		}catch(SQLException e) {e.printStackTrace();}
		return row;
	}
	@Override
	public List<Product> display() {
		List<Product> list = new ArrayList<>();
		try {
			PreparedStatement ps = db.getConnection().prepareStatement("select * from Products");
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				Product p = new Product();
				p.setProductID(rs.getInt(1));
				p.setProductName(rs.getString(2));
				p.setProductPrice(rs.getDouble(3));
				list.add(p);
			}
			db.closeConnection();
		}catch(SQLException e) {e.printStackTrace();}
		return list;
	}
	
}
