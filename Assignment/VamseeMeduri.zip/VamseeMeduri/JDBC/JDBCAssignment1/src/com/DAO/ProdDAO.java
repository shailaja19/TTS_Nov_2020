package com.DAO;

import java.util.List;

import com.Model.*;
public interface ProdDAO {
	public int add(Object ob);
	public int delete(Object ob);
	public int update(Object ob);
	public List<Product> display();
}
