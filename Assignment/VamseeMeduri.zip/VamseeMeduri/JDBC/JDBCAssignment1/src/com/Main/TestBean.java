package com.Main;

import java.sql.SQLException;
import java.util.List;

import com.DAOImplementation.*;
import com.Model.*;

public class TestBean {
	public static void main(String[] args) {
		Product p1 = new Product();
		p1.setProductID(125);
		p1.setProductName("Pantene");
		p1.setProductPrice(75);
		
		Product p2 = new Product();
		p2.setProductID(144);
		p2.setProductName("Pringles");
		p2.setProductPrice(99);
		
		Product p3 = new Product();
		p3.setProductID(156);
		p3.setProductName("Dairy Milk");
		p3.setProductPrice(20);
		
		Product p4 = new Product();
		p4.setProductID(156);
		p4.setProductName("Silk");
		p4.setProductPrice(64);
		
	//---------------------------------------------------------------------	
		DAOImp element = new DAOImp();
		System.out.println("Adding P1, P2, P3");
		element.add(p1);
		element.add(p2);
		element.add(p3);
		List<Product> list = element.display();
		for(Product e : list) {
			System.out.println(e.getProductID());
			System.out.println(e.getProductName());
			System.out.println(e.getProductPrice());
		}

	//---------------------------------------------------------------------
		System.out.println("-------------------------------------------------------");
		System.out.println("Deleting P2 and updating p3");
		element.delete(p2);
		element.update(p4);
		List<Product> list2 = element.display();
		for(Product e : list2) {
			System.out.println(e.getProductID());
			System.out.println(e.getProductName());
			System.out.println(e.getProductPrice());
		}

	}
}
