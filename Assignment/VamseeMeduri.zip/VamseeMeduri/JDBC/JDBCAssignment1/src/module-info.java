module JDBCAssignment1 {
	requires java.sql;
}