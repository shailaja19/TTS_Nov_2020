module JDBCAssignment2 {
	requires java.sql;
}