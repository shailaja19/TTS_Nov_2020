package com.Main;

import com.DAOImplementation.*;
import com.Model.*;
public class StudentDriver {
	public static void main(String[] args) {
		Student s1 = new Student();
		s1.setStudentID(47);
		s1.setMarks(89);
		s1.setStudentName("Vamsee");
		
		Student s2 = new Student();
		s2.setStudentID(52);
		s2.setMarks(56);
		s2.setStudentName("Gopal");
		
		Student s3 = new Student();
		s3.setStudentID(72);
		s3.setMarks(80);
		s3.setStudentName("Mohan");
		
		Student s4 = new Student();
		s4.setStudentID(32);
		s4.setMarks(82);
		s4.setStudentName("Kramer");
		
		Implementation d = new Implementation();
		System.out.println(d.addStudent(s1));
		System.out.println(d.addStudent(s2));
		System.out.println(d.addStudent(s3));
		System.out.println(d.addStudent(s4));
		
		d.getStudents();
		
		System.out.println(d.deleteStudent(s2));
		System.out.println(d.updateStudent(72,75));
		
		d.getStudents();
		
	}
}
