package com.DAO;

import java.util.List;
import com.Model.*;

public interface StudentDAO {
	public int addStudent(Object ob);
	public int updateStudent(int ID, double marks);
	public int deleteStudent(Object ob);
	public List<Student> getAllStudent();
}
