package com.DAOImplementation;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.DAO.*;
import com.Model.*;
import com.Exception.*;
public class Implementation implements StudentDAO{
	int rows = 0;
	DBConnector db = new DBConnector();
	Student st = new Student();
	
	@Override
	public int addStudent(Object ob) {
		st = (Student)ob;
		try {
			PreparedStatement check = db.getConnection().prepareStatement
									("Select studentName from Students where studentID = ?" );
			check.setInt(1, st.getStudentID());
			ResultSet rs = check.executeQuery();
			if(!rs.next()) {
				PreparedStatement ps = db.getConnection().prepareStatement
						("insert into Students values(?,?,?)");
				ps.setInt(1, st.getStudentID());
				ps.setString(2, st.getStudentName());
				ps.setDouble(3, st.getMarks());
				rows = ps.executeUpdate();
			}
			else
				throw new CustomException("This entry already exists");
			db.closeConnection();
		}catch(CustomException e) {e.printStackTrace();}
		catch(SQLException e) {e.printStackTrace();}
		return rows;
	}

	@Override
	public int updateStudent(int ID, double marks) {
		try {
			PreparedStatement ps = db.getConnection().prepareStatement
									("update Students set Marks = ? where StudentID = ?");
			ps.setDouble(1, marks);
			ps.setInt(2, ID);
			rows = ps.executeUpdate();
			db.closeConnection();
		}catch(SQLException e) {e.printStackTrace();}
		return rows;
	}

	@Override
	public int deleteStudent(Object ob) {
		st = (Student)ob;
		try {
			PreparedStatement ps = db.getConnection().prepareStatement
									("delete from Students where studentID =?");
			ps.setInt(1, st.getStudentID());
			rows = ps.executeUpdate();
			db.closeConnection();
		}catch(SQLException e) {e.printStackTrace();}
		return rows;
	}

	@Override
	public List<Student> getAllStudent() {
		List<Student> list = new ArrayList<>();
		try {
			PreparedStatement ps = db.getConnection().prepareStatement
									("select * from Students");
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				Student s = new Student();
				s.setStudentID(rs.getInt(1));
				s.setStudentName(rs.getString(2));
				s.setMarks(rs.getDouble(3));
				list.add(s);
			}
			db.closeConnection();
		}catch(SQLException e) {e.printStackTrace();}
		return list;
	}
	public void getStudents() {
		List<Student> list = new ArrayList<>();
		list = this.getAllStudent();
		list.stream().sorted((s1,s2) -> (int)(s1.getMarks() - s2.getMarks())).forEach(System.out :: println);
	}

}
