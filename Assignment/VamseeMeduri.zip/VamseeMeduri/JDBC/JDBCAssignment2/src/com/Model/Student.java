package com.Model;

public class Student {
	private int studentID;
	private String studentName;
	private double Marks;
	
	public Student(){};
	public Student(int a, String b, double c) {
		this.studentID = a;
		this.Marks = c;
		this.studentName = b;
	}
	
	public int getStudentID() {
		return studentID;
	}
	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public double getMarks() {
		return Marks;
	}
	public void setMarks(double marks) {
		Marks = marks;
	}
	
	@Override
	public String toString() {
		return "Student [studentID=" + studentID + ", studentName=" + studentName + ", Marks=" + Marks + "]";
	}
}
