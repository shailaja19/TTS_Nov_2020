package com.Model;

public class Employee {
	private int EmpID;
	private String EmpName;
	private double EmpSal;
	
	public Employee() {}
	public Employee(int a, String b, double c) {
		this.EmpID = a;
		this.EmpName = b;
		this.EmpSal = c;
	}
	
	public int getEmpID() {
		return EmpID;
	}
	public void setEmpID(int empID) {
		EmpID = empID;
	}
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public double getEmpSal() {
		return EmpSal;
	}
	public void setEmpSal(double empSal) {
		EmpSal = empSal;
	}
	@Override
	public String toString() {
		return "employee [EmpID=" + EmpID + ", EmpName=" + EmpName + ", EmpSal=" + EmpSal + "]";
	}
}
