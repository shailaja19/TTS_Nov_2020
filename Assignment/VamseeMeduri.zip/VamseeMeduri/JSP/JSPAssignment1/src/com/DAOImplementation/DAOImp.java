package com.DAOImplementation;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.DAO.EmpDAO;
import com.Model.*;

public class DAOImp implements EmpDAO {
	int row = 0;
	DBConnector db = new DBConnector();
	Employee emp = new Employee();
	@Override
	public int save(Object object) {
		try {
			emp = (Employee)object;
			PreparedStatement ps = db.getConnection().prepareStatement
					("insert into EmployeeList values (?,?,?)");
			ps.setInt(1, emp.getEmpID());
			ps.setString(2, emp.getEmpName());
			ps.setDouble(3, emp.getEmpSal());
			row = ps.executeUpdate();
			db.closeConnection();
		}catch(SQLException e) {e.printStackTrace();}
		return row;
	}	
}
