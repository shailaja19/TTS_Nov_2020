package com.DAO;

import com.Model.*;

public interface EmpDAO {
	public int save(Object object);
}
