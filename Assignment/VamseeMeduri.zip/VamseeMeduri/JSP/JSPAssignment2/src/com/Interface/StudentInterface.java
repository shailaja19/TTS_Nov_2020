package com.Interface;

import java.util.List;
import com.Model.*;
public interface StudentInterface {
	public int saveObject (StudentBean student);
	public StudentBean returnObject (int studentID);
	public List<StudentBean> display ();
}
