package com.Implementation;

import com.Model.*;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;
import com.Interface.*;

public class StudentImplementation implements StudentInterface{
	StudentBean st = new StudentBean();
	int rows = 0;
	DBConnector db = new DBConnector();
	
	@Override
	public int saveObject(StudentBean student) {
		st = student;
		try {
			PreparedStatement ps = db.getConnection().prepareStatement("INSERT INTO NEWSTUDENTS VALUES (?,?,?)");
			ps.setInt(1, st.getStudentID());
			ps.setString(2, st.getStudentName());
			ps.setDouble(3, st.getStudentMarks());
			rows = ps.executeUpdate();
		}catch(SQLException e) {e.printStackTrace();}
		return rows;
	}

	@Override
	public StudentBean returnObject(int studentID) {
		try {
			PreparedStatement ps = db.getConnection().prepareStatement("SELECT * FROM NEWSTUDENTS WHERE StudentID = ?");
			ps.setInt(1, studentID);
			ResultSet rs = ps.executeQuery();
			st = new StudentBean (rs.getInt(1),rs.getString(2),rs.getDouble(3));
		}catch(SQLException e) {e.printStackTrace();}
		return st;
	}

	@Override
	public List<StudentBean> display() {
		List<StudentBean> list = new ArrayList<>();
		try {
			PreparedStatement ps = db.getConnection().prepareStatement("SELECT * FROM NEWSTUDENTS");
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				list.add(new StudentBean(rs.getInt(1),rs.getString(2),rs.getDouble(3)));
			}
		}catch(SQLException e) {e.printStackTrace();}
		return list;
	}

}
