package com.Main;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Implementation.StudentImplementation;
import com.Model.StudentBean;

/**
 * Servlet implementation class Question3Servlet
 */
@WebServlet("/Question3Servlet")
public class Question3Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Question3Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		
		int stid = Integer.parseInt(request.getParameter("stid"));
		String stname = request.getParameter("stname");
		double stmarks = Double.parseDouble(request.getParameter("stmarks"));
	
		RequestDispatcher dispatcher = request.getRequestDispatcher("/StudentShow.jsp");
		StudentImplementation obj = new StudentImplementation();
		obj.saveObject(new StudentBean(stid,stname,stmarks));
		request.setAttribute("stid", stid );
		request.setAttribute("stname", stname);
		request.setAttribute("stmarks",stmarks);
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
