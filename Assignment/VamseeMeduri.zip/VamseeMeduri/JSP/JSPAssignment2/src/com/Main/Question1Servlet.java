package com.Main;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Implementation.*;
import com.Model.*;
import java.util.List;
/**
 * Servlet implementation class Question1Servlet
 */
@WebServlet("/Question1Servlet")
public class Question1Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Question1Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		
		int stid = Integer.parseInt(request.getParameter("stid"));
		String stname = request.getParameter("stname");
		double stmarks = Double.parseDouble(request.getParameter("stmarks"));
		String task = request.getParameter("task");
	
		session.setAttribute("stid", stid);
	
		StudentImplementation obj = new StudentImplementation();
		//out.println(stid + stname + stmarks + task); // testing if my backend works fin
		
		/*RequestDispatcher dispatcher = request.getRequestDispatcher("Question2Servlet"); This code is for the second question. 
		if(stmarks >80) {
			dispatcher.forward(request, response);
		}*/
		//else {
			if("add".equals(task)) {
				int temp = obj.saveObject(new StudentBean(stid,stname,stmarks));
				out.println(temp);
			}
			else if ("return".equals(task)) {
				StudentBean temp = obj.returnObject(stid);
				out.println(temp);
			}
			else {
				List<StudentBean> list = obj.display();
				for(StudentBean temp : list)
					out.println(temp);
			}
		//}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
