package com.controller;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/helloworld")
public class DayController {
	@RequestMapping(value = "/{var}" ,method = RequestMethod.GET)
	public String method1(Model model) {
		Date date = new Date();
		model.addAttribute("message1", date);
		return "morningpage";
	}
	
	@RequestMapping(value = "/afternoon" ,method = RequestMethod.GET)
	public ModelAndView method2() {
		Date date = new Date();
		ModelAndView model = new ModelAndView("afternoonpage");
		model.addObject("message2", date);
		return model;
	}
	
	@RequestMapping(value = "/evening" ,method = RequestMethod.GET)
	public String method3() {
		return "eveningpage";
	}
	
}
