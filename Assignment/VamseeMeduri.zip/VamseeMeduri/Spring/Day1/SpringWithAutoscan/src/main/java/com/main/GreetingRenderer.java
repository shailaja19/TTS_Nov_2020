package com.main;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("renderer")
public class GreetingRenderer {
	@Autowired
	GreetingProvider gp = null;
	
	public void speak() {
		if(gp == null) {
			 throw new RuntimeException(
	                    "You must set the property messageProvider of class:"
	                            + GreetingRenderer.class.getName());
		}
		System.out.println(gp.getGreeting());
	}
}
