package com.main;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApplication {
	 public static void main(String[] args) throws Exception {

	        // get the bean factory
	        BeanFactory factory = new ClassPathXmlApplicationContext("beans.xml");
	        GreetingRenderer gr = (GreetingRenderer) factory.getBean("renderer");
	        gr.speak();
	    }
}
