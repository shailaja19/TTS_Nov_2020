package com.main;

public class GreetingProvider {
	public String getGreeting() {
		return "Greetings mate!";
	}
}
