import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class StudentTable {
    @Id
    private int StudId;
    private String StudName;
    private double StudMarks;
    public int getStudId() {
        return StudId;
    }
    public void setStudId(int studId) {
        StudId = studId;
    }
    public String getStudName() {
        return StudName;
    }
    public void setStudName(String studName) {
        StudName = studName;
    }
    public double getStudMarks() {
        return StudMarks;
    }
    public void setStudMarks(double studMarks) {
        StudMarks = studMarks;
    }
    @Override
    public String toString() {
        return "StudentTable [StudId=" + StudId + ", StudName=" + StudName + ", StudMarks=" + StudMarks + "]";
    }
}