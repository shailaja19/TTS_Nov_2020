import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class InheritanceTester {

    public static void main(String[] args) {
        Bank b1 = new Bank();
        b1.setCustomerName("Vamsee");

        SavingBank s2= new SavingBank();
        s2.setCustomerName("Vamsee");
        s2.setSbalance(40000);

        CurrentBank c1 = new CurrentBank();
        c1.setCbalance(15000);
        c1.setCustomerName("Vamsee");

        SessionFactory factory= new Configuration().configure().buildSessionFactory();
        Session s1= factory.openSession();
        s1.beginTransaction();
        s1.save(b1);
        s1.save(s2);
        s1.save(c1);
        s1.getTransaction().commit();
        s1.close();
    }
}