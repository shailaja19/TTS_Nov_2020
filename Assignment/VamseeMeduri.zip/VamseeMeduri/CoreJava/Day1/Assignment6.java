package coreJavaDay1;

public class Assignment6 {
	public static void main(String[] arg){
		int[] array = {1,2,3,4,5,6,7};
		for(int i=(array.length-1); i<=0; i--) {
			System.out.println(array[i]);
		}
	}
}
