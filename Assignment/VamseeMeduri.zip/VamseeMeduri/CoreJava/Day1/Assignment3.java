package coreJavaDay1;

public class Assignment3 {
	public static void main(String arg[]) {
		int number = 3;
		System.out.print(number*number*number);
	}
}
