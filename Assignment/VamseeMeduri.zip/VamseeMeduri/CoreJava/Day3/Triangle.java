package com.Assignments;

public class Triangle extends Shape {
	private double angle;
	
	public void findRadius() {
		double temp = Math.toRadians(angle);
		System.out.println((double) this.getBreadth() / Math.sin(temp));
	}
}
