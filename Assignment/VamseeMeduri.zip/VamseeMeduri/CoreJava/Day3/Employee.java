package com.Assignments;

public class Employee {
	private int empID;
	private String empName;
	private int empSal;
	
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		empID = empID;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpSal() {
		return empSal;
	}
	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}
	
	public void salCal() {
		System.out.println(empSal*12);
	}
	
	public void display() {
		System.out.println(this.empID);
		System.out.println(this.empName);
		System.out.println(this.empSal);
		salCal();
	}
	
	@Override
	public String toString() {
		return "Employee [EmpID=" + empID + ", empName=" + empName + ", empSal=" + empSal + "]";
	}
}
