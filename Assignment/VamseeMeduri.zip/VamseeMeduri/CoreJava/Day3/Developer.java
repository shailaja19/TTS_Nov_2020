package com.Assignments;

public class Developer extends Employee {
	private String developerBonus;

	public String getAssignedProject() {
		return developerBonus;
	}
	public void setAssignedProject(String assignedProject) {
		this.developerBonus = assignedProject;
	}
	
	public void salCal() {
		System.out.println(this.getEmpSal() + developerBonus);
	}
}
