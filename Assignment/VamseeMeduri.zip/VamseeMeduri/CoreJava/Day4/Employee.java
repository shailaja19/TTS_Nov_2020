package com.Assignments;

abstract class Employee {
	private int employeeID;
	private String employeeName;
	private Address address;
	private double basicPay;
	private int leavesAvailable;
	
	public Employee() {};
	public Employee (int a, String b, Address c, double d, int e) {
		this.employeeID = a;
		this.employeeName = b;
		this.address = c;
		this.basicPay = d;
		this.leavesAvailable = e;
	}
	
	public abstract double calculateSalary();
	public int getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public double getBasicPay() {
		return basicPay;
	}
	public void setBasicPay(double basicPay) {
		this.basicPay = basicPay;
	}
	public int getLeavesAvailable() {
		return leavesAvailable;
	}
	public void setLeavesAvailable(int leavesAvailable) {
		this.leavesAvailable = leavesAvailable;
	}
	
	
	
	@Override
	public String toString() {
		return "Employee [employeeName=" + employeeName + ", address=" + address + ", basicPay=" + basicPay
				+ ", leavesAvailable=" + leavesAvailable + ", employeeID=" + employeeID + "]";
	}
	
	
}
