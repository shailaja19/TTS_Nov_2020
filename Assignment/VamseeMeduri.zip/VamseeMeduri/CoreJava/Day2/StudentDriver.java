package com.Assignments;

public class StudentDriver {
	public static void main(String[] arg) {
		Student s1 = new Student();
		s1.setStudentID(1562);
		s1.setStudentName("Vamsee");
		s1.setStudentClass(10);
		
		Student s2 = new Student();
		s2.setStudentID(1453);
		s2.setStudentName("Gopal");
		s2.setStudentClass(8);
		
		System.out.println(s1);
		System.out.println(s2);
	}	
}
