package com.Assignments;

public class Tshirt {
	private String colour;
	private String material;
	private String design;
	private String size;
	
	Tshirt(){
		this.colour = "Red";
		this.material = "Nylon";
		this.design = "Plain";
		this.size = "S";
	}
	
}

