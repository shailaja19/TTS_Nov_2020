package com.Assignments;

public class ProductDriver {
	public static void main(String[] arg) {
		Product p1 = new Product();
		p1.setProductID(1152);
		p1.setProductName("Pantene");
		p1.setProductPrice(47.00);
		
		System.out.println(p1);
	}
}
