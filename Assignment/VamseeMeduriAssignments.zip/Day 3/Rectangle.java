package com.Assignments;

public class Rectangle extends Shape {
	public void findRadius() {
		System.out.println(this.getLength() * 2);
	}
}
