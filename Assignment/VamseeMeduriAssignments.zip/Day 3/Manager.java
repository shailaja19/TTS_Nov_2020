package com.Assignments;

public class Manager extends Employee {
	private String managerBonus;

	public String getAssignedProject() {
		return managerBonus;
	}
	public void setAssignedProject(String assignedProject) {
		this.managerBonus = assignedProject;
	}
	
	public void salCal() {
		System.out.println(this.getEmpSal() + managerBonus);
	}
}
