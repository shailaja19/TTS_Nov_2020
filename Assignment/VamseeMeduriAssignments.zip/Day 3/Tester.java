package com.Assignments;

public class Tester extends Employee{
	private String testerBonus;

	public String getAssignedProject() {
		return testerBonus;
	}
	public void setAssignedProject(String assignedProject) {
		this.testerBonus = assignedProject;
	}
	
	public void salCal() {
		System.out.println(this.getEmpSal() + testerBonus);
	}
}
