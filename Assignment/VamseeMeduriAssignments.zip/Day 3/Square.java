package com.Assignments;

public class Square extends Shape {
	public void findRadius() {
		System.out.println(this.getLength() * 2);
	}
}
