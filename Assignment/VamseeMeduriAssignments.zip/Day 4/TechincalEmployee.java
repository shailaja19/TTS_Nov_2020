package com.Assignments;

public class TechincalEmployee extends Employee{
	private String skill;
	
	
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}

	@Override
	public double calculateSalary() {
		return (this.getBasicPay() * 1.12);
	}
	@Override
	public String toString() {
		return "TechincalEmployee [skill=" + skill + "]";
	}
}
