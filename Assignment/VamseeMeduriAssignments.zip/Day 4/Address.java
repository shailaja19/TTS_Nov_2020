package com.Assignments;

public class Address {
	private int doorNo;
	private String street;
	private String city;
	private int pinCode;
	
	public Address() {};
	public Address(int a, String b, String c, int d) {
		this.doorNo = a;
		this.street = b;
		this.city = c;
		this.pinCode = d;
	}
	
	public int getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(int doorNo) {
		this.doorNo = doorNo;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	
	@Override
	public String toString() {
		return "Address [street=" + street + ", city=" + city + ", pinCode=" + pinCode + ", doorNo=" + doorNo + "]";
	}	
}
