package com.Assignments;

public class Staff extends Employee {
	private String title;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public double calculateSalary() {
		return (this.getBasicPay() * 1.18);
	}
	@Override
	public String toString() {
		return "Staff [title=" + title + "]";
	}
}
