package coreJavaDay1;

public class Assignment4 {
	public static void main(String[] arg) {
		int array[] = {1,2,3,4,5,6};
		int sum = 0;
		for(int i=0; i<array.length; i++)
			sum+=array[i];
		System.out.print(sum);
	}
}
