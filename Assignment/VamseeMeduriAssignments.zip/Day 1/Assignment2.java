package coreJavaDay1;

public class Assignment2 {
	public static void main(String arg[]) {
		for(int i=1; i<=10; i++)
			System.out.println(i);
	}
}
